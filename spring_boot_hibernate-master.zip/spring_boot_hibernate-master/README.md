# spring_boot_hibernate

This project is an implementation of Spring Boot with Hibernate support.

This project can be deployed as a standalone jar or even in a container like tomcat/jboss etc..


